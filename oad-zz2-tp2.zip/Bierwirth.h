#ifndef BIERWIRTH_H
#define BIERWIRTH_H

#include <vector>
#include <list>
#include "Data.h"

class Bierwirth
{
    int n, //nb jobs
        m; //nb machines
    std::vector<int> bierwirth_vector;
    std::vector<int> dateFinJob; //On a pour chaque job sa dernière date d'utilisation par une machine
    std::vector<int> dateFinOperationMachine; //On a pour chaque machine sa dernière date d'utilisation pour un job
    std::vector<Operation*> operations; //vecteurs contenant toutes les opérations traitées dans l'ordre du vecteur de bierwirth

    Operation lastOp;

public:
    Bierwirth(int n, int m);

    void shuffle();
    void initializeVectors();
    int evaluate(Data &d, Operation &derniereOperation);

    Operation* trouverMachinePrec(std::vector<Operation*> &operations, int operationsSize, int numeroMachine);
    void cheminCritique(std::list<Operation*> &listeCheminCritique, Operation *derniereOperation);

    void rechercheLocale(Data &d);
    int getIndexPere(Operation *pere);
    void swap_bierwirth_vector(int a, int b);
    void swap_operations_vector(int a, int b);
};

#endif // BIERWIRTH_H
